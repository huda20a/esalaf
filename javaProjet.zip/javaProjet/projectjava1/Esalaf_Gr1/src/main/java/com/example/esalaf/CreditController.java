package com.example.esalaf;
import com.exemple.model.Credit;
import com.exemple.model.CreditDAO;
import com.exemple.model.Produit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Double.parseDouble ;
import static java.lang.Long.parseLong;

public class CreditController implements Initializable {
    @FXML
    private Button menu;
    @FXML
    private TextField id_client;
    @FXML
    private TextField id_produit;

    @FXML
    private TextField prix;

    @FXML
    private TableView<Credit> mytab;

    @FXML
    private TableColumn<Credit, Long> col_id_credit;
    @FXML
    private TableColumn<Credit, Long> col_id_client;
    @FXML
    private TableColumn<Credit, Long> col_id_produit;
    @FXML
    private TableColumn<Credit, Double> col_prix;

    @FXML
    protected void onSaveButtonClick(){

        Credit cli = new Credit (0l , parseLong(id_client.getText()), parseLong(id_produit.getText()) , parseDouble(prix.getText())) ;

        try {
            CreditDAO clidao = new CreditDAO();

            clidao.save(cli);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        UpdateTable();

    }

    @FXML
    private void onDeleteButtonClick() {
        Credit selectedCredit = mytab.getSelectionModel().getSelectedItem();
        if (selectedCredit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for deletion");
            return;
        }
        try {
            CreditDAO creditDAO = new CreditDAO();
            creditDAO.delete(selectedCredit);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    protected void onUpdateButtonClick() {

        Credit selecteCredit= mytab.getSelectionModel().getSelectedItem();

        if (selecteCredit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for update");
            return;
        }

        try {
            CreditDAO creditDAO = new CreditDAO();

            // Update the credit object with the new data
            //selecteCredit.setId_client(parseLong(id_client.getText()));
            // Update the Credit object with the new data
            selecteCredit.setId_client(parseLong(id_client.getText()));
            selecteCredit.setId_produit(parseLong(id_produit.getText()));
            selecteCredit.setPrix(parseDouble(prix.getText()));

            creditDAO.update(selecteCredit);

            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    @FXML
    void afficherMenu (ActionEvent event) {
        try {
            // Load the FXML file for the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu-view.fxml"));
            Parent root = loader.load();

            // Create a new scene with the root node
            Scene scene = new Scene(root);

            // Get the current stage and set the new sceneS
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void UpdateTable(){
        col_id_credit.setCellValueFactory(new PropertyValueFactory<Credit,Long>("id_credit"));
        col_id_client.setCellValueFactory(new PropertyValueFactory<Credit,Long>("id_client"));
        col_id_produit.setCellValueFactory(new PropertyValueFactory<Credit,Long>("id_produit"));
        col_prix.setCellValueFactory(new PropertyValueFactory<Credit,Double>("prix"));

        mytab.setItems(getDataCredits());
    }

    public static ObservableList<Credit> getDataCredits(){

        CreditDAO clidao = null;

        ObservableList<Credit> listfx = FXCollections.observableArrayList();

        try {
            clidao = new CreditDAO();
            for(Credit ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }

}
