package com.exemple.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CreditDAO extends BaseDAO<Credit>{

    public CreditDAO() throws SQLException{
        super();
    }
    // mapping objet --> relation
    @Override
    public void save(Credit object) throws SQLException {

        String req = "insert into credit (id_client ,id_produit, prix) values ( ?, ? , ? ) ;";

        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1 , object.getId_client());
        this.preparedStatement.setLong(2 , object.getId_produit());
        this.preparedStatement.setDouble(3 , object.getPrix());
        this.preparedStatement.execute();
    }

    @Override
    public void update(Credit object) throws SQLException {
        String req = "update credit set id_client = ?,id_produit = ?, prix = ? where id_credit = ?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(req);

        // mapping
        this.preparedStatement.setLong(2 , object.getId_client());
        this.preparedStatement.setLong(3 , object.getId_produit());
        this.preparedStatement.setDouble(4, object.getPrix());
        this.preparedStatement.setLong(1 , object.getId_credit());
        this.preparedStatement.execute();

    }
    @Override
    public void delete(Credit object) throws SQLException {
        String req = "delete from credit where id_credit = ?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(req);

        // mapping
        this.preparedStatement.setLong(1 , object.getId_credit());

        this.preparedStatement.execute();

    }
    @Override
    public Credit getOne(Long id) throws SQLException {
        return null;
    }

    // mapping relation --> objet
    @Override
    public List<Credit> getAll() throws SQLException{

        List<Credit> mylist = new ArrayList<Credit>();
        String req = " select * from Credit" ;


        this.statement = this.connection.createStatement();

        this.resultSet =  this.statement.executeQuery(req);

        while (this.resultSet.next()){

            mylist.add(new Credit(this.resultSet.getLong(1) , this.resultSet.getLong(2) , this.resultSet.getLong(3) , this.resultSet.getDouble(4)));

        }

        return mylist;
    }




}


