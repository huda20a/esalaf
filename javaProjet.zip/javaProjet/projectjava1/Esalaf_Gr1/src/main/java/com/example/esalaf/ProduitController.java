package com.example.esalaf;

import com.exemple.model.Produit;
import com.exemple.model.ProduitDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Double.parseDouble ;



public class ProduitController implements Initializable {

    @FXML
    private TextField nom;

    @FXML
    private TextField price;

    @FXML
    private TableView<Produit> mytab;

    @FXML
    private TableColumn<Produit, Long> col_id;

    @FXML
    private TableColumn<Produit, String> col_nom;

    @FXML
    private TableColumn<Produit, Double> col_price;

    @FXML
    private Button menu;

    @FXML
    protected void onSaveButtonClick(){

        Produit cli = new Produit (0l , nom.getText(), parseDouble(price.getText())) ;

        try {
            ProduitDAO clidao = new ProduitDAO();

            clidao.save(cli);



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        UpdateTable();

    }
    @FXML
    private void onDeleteButtonClick() {
        Produit selectedProduit = mytab.getSelectionModel().getSelectedItem();
        if (selectedProduit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for deletion");
            return;
        }
        try {
            ProduitDAO produitDAO = new ProduitDAO();
            produitDAO.delete(selectedProduit);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    protected void onUpdateButtonClick() {

        Produit selecteProduit = mytab.getSelectionModel().getSelectedItem();

        if (selecteProduit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for update");
            return;
        }

        try {
            ProduitDAO produitDAO = new ProduitDAO();

            // Update the Produit object with the new data
            selecteProduit.setNom(nom.getText());
            selecteProduit.setPrice(parseDouble(price.getText()));

            produitDAO.update(selecteProduit);

            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    @FXML
    void afficherMenu (ActionEvent event) {
        try {
            // Load the FXML file for the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu-view.fxml"));
            Parent root = loader.load();

            // Create a new scene with the root node
            Scene scene = new Scene(root);

            // Get the current stage and set the new sceneS
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Produit,Long>("id_produit"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Produit,String>("nom"));
        col_price.setCellValueFactory(new PropertyValueFactory<Produit,Double>("price"));

        mytab.setItems(getDataProduits());
    }

    public static ObservableList<Produit> getDataProduits(){

        ProduitDAO clidao = null;

        ObservableList<Produit> listfx = FXCollections.observableArrayList();

        try {
            clidao = new ProduitDAO();
            for(Produit ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }
}

