package com.exemple.model;

public class Produit {

    private Long id_produit ;

    private String nom ;

    private Double price ;

    public Produit(long l, long parseLong, long aLong, double v) {
    }

    public Produit(Long id_produit, String nom, Double price) {
        this.id_produit = id_produit;
        this.nom = nom;
        this.price = price;
    }

    public Long getId_produit() {
        return id_produit;
    }


    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Client{" +
                "id_produit=" + id_produit +
                ", nom='" + nom + '\'' +
                ", price='" + price + '\'' +
                '}';
    }
}
