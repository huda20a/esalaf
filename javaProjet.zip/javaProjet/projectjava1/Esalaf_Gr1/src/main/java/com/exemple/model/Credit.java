package com.exemple.model;

public class Credit {
    private long id_credit ;
    private long id_client ;
    private long id_produit ;
    private double prix;
    public Credit() {

    }
    public Credit(Long id_credit,long id_client,long id_produit, Double prix) {
        this.id_credit = id_credit;
        this.id_client = id_client;
        this.id_produit = id_produit;
        this.prix = prix;
    }

    public Long getId_credit() {
        return id_credit;
    }
    public void setId_credit(long id_credit) {
        this.id_credit = id_credit;
    }
    public Long getId_client() {
        return id_client;
    }
    public void setId_client(long id_client) {
        this.id_client = id_client;
    }
    public Long getId_produit() {
        return id_produit;
    }
    public void setId_produit(long id_produit) {
        this.id_produit = id_produit;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }


    @Override
    public String toString() {
        return "Client{" +
                "id_credit=" + id_credit +
                "id_client=" + id_client +
                "id_produit=" + id_produit +
                ", prix'" + prix+ '\'' +
                '}';
    }
}

